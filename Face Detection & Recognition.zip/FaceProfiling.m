
function varargout = FaceProfiling(varargin)
% FACEPROFILING MATLAB code for FaceProfiling.fig
%      FACEPROFILING, by itself, creates a new FACEPROFILING or raises the existing
%      singleton*.
%
%      H = FACEPROFILING returns the handle to a new FACEPROFILING or the handle to
%      the existing singleton*.
%
%      FACEPROFILING('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in FACEPROFILING.M with the given input arguments.
%
%      FACEPROFILING('Property','Value',...) creates a new FACEPROFILING or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before FaceProfiling_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to FaceProfiling_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help FaceProfiling

% Last Modified by GUIDE v2.5 16-Jan-2017 11:34:33

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @FaceProfiling_OpeningFcn, ...
                   'gui_OutputFcn',  @FaceProfiling_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before FaceProfiling is made visible.
function FaceProfiling_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to FaceProfiling (see VARARGIN)
%global counterTrainer; % counterTrainer = 1 ;
%global counterCache;    %counterCache = 1 ;
global OutputAddress;   OutputAddress = 'NoFileSelected.png';
global FaceAddress ;
global SubmitFlag ;     SubmitFlag = 0 ;
global Profiles;
global Iterations;      Iterations = 120000;
global IdentifiedAddress;

%Load Default Photos
imshow('VideoInput.png', 'Parent', handles.MMInput);
imshow(OutputAddress, 'Parent', handles.MMOutput);
imshow('Logo.png', 'Parent', handles.Logo);
imshow('Unauthorized.png', 'Parent', handles.NewFace);
imshow('Unauthorized2.png', 'Parent', handles.DetectedFace);

%Set First-Time-Run Buttons and Panels
set(handles.BrowseFile,'enable','off');
set(handles.ShotWebcam,'enable','off');
set(handles.DetectFaces,'enable','off');
set(handles.ChooseAction,'enable','off');
set(handles.SUBMIT,'enable','off');
set(handles.RESET,'enable','off');
set(findall(handles.RegisterPanel, '-property', 'enable'), 'enable', 'off')
set(findall(handles.RecognitionPanel, '-property', 'enable'), 'enable', 'off')



% Choose default command line output for FaceProfiling
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes FaceProfiling wait for user response (see UIRESUME)
% uiwait(handles.FaceProfiling);


% --- Outputs from this function are returned to the command line.
function varargout = FaceProfiling_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes when user attempts to close FaceProfiling.
function FaceProfiling_CloseRequestFcn(hObject, eventdata, handles)
% hObject    handle to FaceProfiling (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: delete(hObject) closes the figure
delete(hObject);



function edit7_Callback(hObject, eventdata, handles)
% hObject    handle to edit7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit7 as text
%        str2double(get(hObject,'String')) returns contents of edit7 as a double


% --- Executes during object creation, after setting all properties.
function edit7_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit6_Callback(hObject, eventdata, handles)
% hObject    handle to edit6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit6 as text
%        str2double(get(hObject,'String')) returns contents of edit6 as a double


% --- Executes during object creation, after setting all properties.
function edit6_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in StartIdentification.
function StartIdentification_Callback(hObject, eventdata, handles)
% hObject    handle to StartIdentification (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global IdentifiedAddress;
imshow(IdentifiedAddress, 'Parent', handles.DetectedFace);
guidata(hObject,handles)




% --- Executes on button press in pushbutton12.
function pushbutton12_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton12 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in NewProfile.
function NewProfile_Callback(hObject, eventdata, handles)
% hObject    handle to NewProfile (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global FaceAddress;
global counterTrainer;
global img;
global Profiles;
%NewName = get(handles.NameRegister,'String');
xyz = imread(FaceAddress) ;
TrainAddress = strcat('traindatabase/' ,num2str(counterTrainer), '.bmp'); %this is where and what your image will be saved
imwrite(xyz, TrainAddress);
%Profiles(counterTrainer,:)=[counterTrainer ExistingID];
counterTrainer = counterTrainer+1;
NewID = get(handles.IDNumberRegister,'String');
NewName = get(handles.NameRegister,'String');
%Profiles(counterTrainer,:)=[counterTrainer NewID NewName];

guidata(hObject,handles)





% --- Executes on button press in AddToExisting.
function AddToExisting_Callback(hObject, eventdata, handles)
% hObject    handle to AddToExisting (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
ExistingID = str2num(get(handles.IDNumberExisting,'String'));
global FaceAddress;
global counterTrainer;
global img;
%global Profiles;
xyz = imread(FaceAddress) ;
TrainAddress = strcat('traindatabase/' ,num2str(counterTrainer), '.bmp'); %this is where and what your image will be saved
imwrite(xyz, TrainAddress);
%Profiles(counterTrainer,:)=[counterTrainer ExistingID];
counterTrainer = counterTrainer+1;
guidata(hObject,handles)





function IDNumberExisting_Callback(hObject, eventdata, handles)
% hObject    handle to IDNumberExisting (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of IDNumberExisting as text
%        str2double(get(hObject,'String')) returns contents of IDNumberExisting as a double

% --- Executes during object creation, after setting all properties.
function IDNumberExisting_CreateFcn(hObject, eventdata, handles)
% hObject    handle to IDNumberExisting (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function IDNumberRegister_Callback(hObject, eventdata, handles)
% hObject    handle to IDNumberRegister (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of IDNumberRegister as text
%        str2double(get(hObject,'String')) returns contents of IDNumberRegister as a double


% --- Executes during object creation, after setting all properties.
function IDNumberRegister_CreateFcn(hObject, eventdata, handles)
% hObject    handle to IDNumberRegister (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function NameRegister_Callback(hObject, eventdata, handles)
% hObject    handle to NameRegister (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of NameRegister as text
%        str2double(get(hObject,'String')) returns contents of NameRegister as a double


% --- Executes during object creation, after setting all properties.
function NameRegister_CreateFcn(hObject, eventdata, handles)
% hObject    handle to NameRegister (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in ChooseInput.
function ChooseInput_Callback(hObject, eventdata, handles)
% hObject    handle to ChooseInput (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns ChooseInput contents as cell array
%        contents{get(hObject,'Value')} returns selected item from ChooseInput
% Determine the selected data set.
str = get(hObject, 'String');
val = get(hObject,'Value');
% Set current data to the selected data set.
switch str{val};
    case 'Choose Input' 
        set(handles.RESET,'enable','on');
        imshow('VideoInput.png', 'Parent', handles.MMInput);
        set(handles.ShotWebcam,'enable','off');
        set(handles.BrowseFile,'enable','off');
    case 'Webcam' 
        set(handles.RESET,'enable','on');
        obj = videoinput('macvideo', 1);
        vidRes=obj.VideoResolution;
        nBands=obj.NumberOfBands;   
        hImage=image(zeros(vidRes(2), vidRes(1), nBands),'Parent',handles.MMInput); 
        preview(obj,hImage);    
        set(handles.ShotWebcam,'enable','on');
        set(handles.BrowseFile,'enable','off');
    case 'Browse File' 
        set(handles.RESET,'enable','on');
        imshow('BrowseFile.png', 'Parent', handles.MMInput);
        set(handles.BrowseFile,'enable','on');
        set(handles.ShotWebcam,'enable','off');
end
% Save the handles structure.
guidata(hObject,handles)



% --- Executes during object creation, after setting all properties.
function ChooseInput_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ChooseInput (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in ShotWebcam.
function ShotWebcam_Callback(hObject, eventdata, handles)
% hObject    handle to ShotWebcam (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global counterCache;
objectShot = videoinput('macvideo', 1);
set(objectShot,'ReturnedColorSpace', 'RGB');
global img;
img = getsnapshot(objectShot);
savename = strcat('Cache/' ,num2str(counterCache), '.jpg'); %this is where and what your image will be saved
imwrite(img, savename);
delete(objectShot)
%imshow('VideoInput.png', 'Parent', handles.MMInput);
counterCache = counterCache +1;  %counterCache should increment each time you push the button
global OutputAddress;
OutputAddress=savename;
imshow(OutputAddress, 'Parent', handles.MMOutput);
set(handles.DetectFaces,'enable','on');
guidata(hObject,handles);

% --- Executes on button press in BrowseFile.
function BrowseFile_Callback(hObject, eventdata, handles)
% hObject    handle to BrowseFile (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%dname = uigetfile('/Users/apple');
[FileName,PathName]=uigetfile('*.bmp','Select');
FullPath=strcat(PathName,FileName);
copyfile(FullPath,'../Face Detection & Recognition/Cache/');
imaddress=strcat('../Face Detection & Recognition/Cache/',FileName);
global OutputAddress ;
OutputAddress = imaddress;
imshow(imaddress, 'Parent', handles.MMOutput);
set(handles.DetectFaces,'enable','on');
guidata(hObject,handles);



% --- Executes on button press in DetectFaces.
function DetectFaces_Callback(hObject, eventdata, handles)
% hObject    handle to DetectFaces (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
faceDetector=vision.CascadeObjectDetector('FrontalFaceCART'); %Create a detector object
global OutputAddress ;
global counterCache ;
global FaceAddress ;
global counterFace;
img=imread(OutputAddress); %Read input image
img=rgb2gray(img); % convert to gray
BB=step(faceDetector,img); % Detect faces
iimg = insertObjectAnnotation(img, 'rectangle', BB, 'Face', 'LineWidth', 10); %Annotate detected faces.
imshow(iimg, 'Parent', handles.MMOutput);
%title('Detected face');
%htextinsface = vision.TextInserter('Text', 'face   : %2d', 'Location',  [5 2],'Font', 'Courier New','FontSize', 14);
set(handles.ChooseAction,'enable','on');

%%%%
face=imcrop(img,[BB(1,1) BB(1,2) 330 350]);%BB(1,:));
FaceAddress = strcat('../Face Detection & Recognition/FaceCache/' ,num2str(counterFace), '.bmp');
imwrite(face, FaceAddress);
counterFace = counterFace+1;
%%%
guidata(hObject,handles);



% --- Executes on selection change in ChooseAction.
function ChooseAction_Callback(hObject, eventdata, handles)
% hObject    handle to ChooseAction (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns ChooseAction contents as cell array
%        contents{get(hObject,'Value')} returns selected item from ChooseAction
% Determine the selected data set.
str = get(hObject, 'String');
val = get(hObject,'Value');
global SubmitFlag ;
% Set current data to the selected data set.
switch str{val};
    case 'Choose Action' 
        SubmitFlag = 0 ;
        set(handles.SUBMIT,'enable','off');
        set(findall(handles.RecognitionPanel, '-property', 'enable'), 'enable', 'off')
        set(findall(handles.RegisterPanel, '-property', 'enable'), 'enable', 'off')
    case 'Add Face(s) to Database' 
        SubmitFlag = 1 ;
        set(handles.SUBMIT,'enable','on');
    case 'Recognize Face' 
        SubmitFlag = 2 ;
        set(handles.SUBMIT,'enable','on');
end
% Save the handles structure.
guidata(hObject,handles)

% --- Executes during object creation, after setting all properties.
function ChooseAction_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ChooseAction (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in SUBMIT.
function SUBMIT_Callback(hObject, eventdata, handles)
% hObject    handle to SUBMIT (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global SubmitFlag ;
global FaceAddress ;
global counterFace ;
global IdentifiedAddress;
switch SubmitFlag;
    case 0
        set(findall(handles.RecognitionPanel, '-property', 'enable'), 'enable', 'off')
        set(findall(handles.RegisterPanel, '-property', 'enable'), 'enable', 'off')
        imshow('Unauthorized.png', 'Parent', handles.NewFace);
        imshow('Unauthorized2.png', 'Parent', handles.DetectedFace);
    case 1
        imshow(FaceAddress, 'Parent', handles.NewFace);
        imshow('Unauthorized2.png', 'Parent', handles.DetectedFace);
        set(findall(handles.RegisterPanel, '-property', 'enable'), 'enable', 'on')
        set(findall(handles.RecognitionPanel, '-property', 'enable'), 'enable', 'off')
    case 2
        %imshow(FaceAddress, 'Parent', handles.DetectedFace);
        imshow('Unauthorized.png', 'Parent', handles.NewFace);
        set(findall(handles.RecognitionPanel, '-property', 'enable'), 'enable', 'on')
        set(findall(handles.RegisterPanel, '-property', 'enable'), 'enable', 'off')
        IdentifiedAddress = Recognition(FaceAddress);
end

guidata(hObject,handles)


% --- Executes on button press in RESET.
function RESET_Callback(hObject, eventdata, handles)
% hObject    handle to RESET (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
  close(gcbf);
  FaceProfiling
%guidata(hObject,handles);


% --- Executes on button press in TrainNetwork.
function TrainNetwork_Callback(hObject, eventdata, handles)
% hObject    handle to TrainNetwork (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global Iterations;
Iterations = str2num(get(handles.IterationsNN,'String'));
Learn(Iterations);
guidata(hObject,handles);



% --- Executes on button press in DeleteCache.
function DeleteCache_Callback(hObject, eventdata, handles)
% hObject    handle to DeleteCache (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
delete('Cache/*.jpg');
delete('FaceCache/*.bmp');
%delete('TrainDirectory/*.jpg');
global counterCache;
global counterTrainer;
global counterFace;
counterCache = 1 ;
counterFace = 1 ;
%counterTrainer = 1 ;
guidata(hObject,handles);



function IterationsNN_Callback(hObject, eventdata, handles)
% hObject    handle to IterationsNN (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of IterationsNN as text
%        str2double(get(hObject,'String')) returns contents of IterationsNN as a double
global Iterations;
Iterations = str2num(get(handles.IterationsNN,'String'));
guidata(hObject,handles);




% --- Executes during object creation, after setting all properties.
function IterationsNN_CreateFcn(hObject, eventdata, handles)
% hObject    handle to IterationsNN (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
