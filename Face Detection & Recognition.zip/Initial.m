global counterTrainer;
global counterCache;
global counterFace;
counterTrainer = 1 ;
counterCache = 1 ;
counterFace = 1 ;
FaceProfiling