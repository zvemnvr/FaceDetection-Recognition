
function [RecAdd]=Recognition(FaceAdd)
global NN ;
global WRONGG ;
TrainDatabasePath = 'traindatabase/';

TestImage = FaceAdd; %strcat(TestDatabasePath,'/',char(TestImage),'.bmp');
im = imread(TestImage);
recognition_rate=abs(50*(size(NN,2)-WRONGG)/size(NN,2))

T = CreateDatabase(TrainDatabasePath);
[m, A, Eigenfaces] = face(T);
OutputName = recog(TestImage, m, A, Eigenfaces);

SelectedImage = strcat(TrainDatabasePath,'/',OutputName);
SelectedImage = imread(SelectedImage);

%imshow(im)
%title('Image to be tested');
%figure,imshow(SelectedImage);
%title('Equivalent Image');
%disp('Face Recognition successful');
RecAdd = SelectedImage ;
end